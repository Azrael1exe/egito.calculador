import { FormEvent, useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

type Product = {
  id: string;
  name: string;
  price: number;
  createdAt: string;
};

type SaleItem = {
  productId: string;
  productName: string;
  quantity: number;
  unitPrice: number;
  total: number;
};

type Sale = {
  id: string;
  items: SaleItem[];
  total: number;
  timestamp: string;
  orgCommissionPercent: number;
  memberCommissionPercent: number;
  memberName: string;
  orgCommissionValue: number;
  memberCommissionValue: number;
};

type LogLevel = "INFO" | "WARN" | "ERROR";

type LogEntry = {
  id: string;
  action: string;
  message: string;
  level: LogLevel;
  timestamp: string;
  meta?: string;
};

type DiscordConfig = {
  botName: string;
  avatarUrl: string;
  enabled: boolean;
  defaultMention: string;
  signature: string;
  retryAttempts: number;
  retryDelayMs: number;
  requestTimeoutMs: number;
  maxMessagesPerMinute: number;
  deduplicateSales: boolean;
  saleCooldownSeconds: number;
  circuitBreakerFailures: number;
  circuitBreakerCooldownSeconds: number;
  quietHoursStart: number;
  quietHoursEnd: number;
  saleTemplate: string;
  commissionTemplate: string;
  manualTemplate: string;
  commissionAlertThreshold: number;
  digestHour: number;
  digestLastSentAt: string;
  channels: DiscordChannel[];
};

type DiscordChannel = {
  id: string;
  name: string;
  webhookUrl: string;
  enabled: boolean;
  mention: string;
  useEmbeds: boolean;
  sendSales: boolean;
  sendCommissionAlerts: boolean;
  sendDigest: boolean;
  allowManualCommands: boolean;
  pausedUntil: string;
  minSaleValue: number;
};

type CommissionConfig = {
  orgPercent: number;
  memberPercent: number;
  memberName: string;
};

type DashboardState = {
  products: Product[];
  sales: Sale[];
  logs: LogEntry[];
  discordConfig: DiscordConfig;
  commissionConfig: CommissionConfig;
};

type SaleDraftItem = {
  id: string;
  productId: string;
  quantity: string;
};

type DiscordChannelDraft = {
  name: string;
  webhookUrl: string;
  mention: string;
  useEmbeds: boolean;
  sendSales: boolean;
  sendCommissionAlerts: boolean;
  sendDigest: boolean;
  allowManualCommands: boolean;
  minSaleValue: string;
};

type DiscordRuntimeState = {
  sentWindowStart: string;
  sentInWindow: number;
  lastError: string;
  lastSuccessAt: string;
  successfulDispatches: number;
  failedDispatches: number;
  saleDispatchByChannel: Record<string, string>;
  saleHashByChannel: Record<string, string>;
  consecutiveFailuresByChannel: Record<string, number>;
  channelCircuitOpenUntil: Record<string, string>;
};

type ToastState = {
  id: string;
  text: string;
  tone: "info" | "success" | "error";
};

type SystemAuditReport = {
  totalIssues: number;
  fixedIssues: number;
  warnings: string[];
};

const STORAGE_KEYS = {
  products: "sales_dashboard_products",
  sales: "sales_dashboard_sales",
  logs: "sales_dashboard_logs",
  discordConfig: "sales_dashboard_discord",
  commissionConfig: "sales_dashboard_commission",
  discordRuntime: "sales_dashboard_discord_runtime",
};

const INITIAL_DISCORD_CONFIG: DiscordConfig = {
  botName: "EGITO",
  avatarUrl: "",
  enabled: false,
  defaultMention: "",
  signature: "EGITO Control Center",
  retryAttempts: 2,
  retryDelayMs: 800,
  requestTimeoutMs: 5000,
  maxMessagesPerMinute: 20,
  deduplicateSales: true,
  saleCooldownSeconds: 20,
  circuitBreakerFailures: 3,
  circuitBreakerCooldownSeconds: 90,
  quietHoursStart: 23,
  quietHoursEnd: 7,
  saleTemplate:
    "Nova venda em {datetime} | Total: {total} | Itens: {items} | Org: {orgCommission} | {member}: {memberCommission}",
  commissionTemplate:
    "Comissao alta detectada em {datetime} | {member}: {memberCommission} | Org: {orgCommission} | Total venda: {total}",
  manualTemplate: "{message}",
  commissionAlertThreshold: 500,
  digestHour: 20,
  digestLastSentAt: "",
  channels: [],
};

const INITIAL_COMMISSION_CONFIG: CommissionConfig = {
  orgPercent: 12,
  memberPercent: 8,
  memberName: "Membro Padrao",
};

const INITIAL_DISCORD_CHANNEL_DRAFT: DiscordChannelDraft = {
  name: "#vendas",
  webhookUrl: "",
  mention: "",
  useEmbeds: true,
  sendSales: true,
  sendCommissionAlerts: false,
  sendDigest: true,
  allowManualCommands: true,
  minSaleValue: "0",
};

const INITIAL_DISCORD_RUNTIME: DiscordRuntimeState = {
  sentWindowStart: "",
  sentInWindow: 0,
  lastError: "",
  lastSuccessAt: "",
  successfulDispatches: 0,
  failedDispatches: 0,
  saleDispatchByChannel: {},
  saleHashByChannel: {},
  consecutiveFailuresByChannel: {},
  channelCircuitOpenUntil: {},
};

const MAX_LOGS = 250;

const currencyFormatter = new Intl.NumberFormat("pt-BR", {
  style: "currency",
  currency: "BRL",
});

const numberFormatter = new Intl.NumberFormat("pt-BR");

function createId(prefix: string) {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
}

class LocalBackend {
  private discordQueue: Promise<void> = Promise.resolve();

  private read<T>(key: string, fallback: T): T {
    const raw = localStorage.getItem(key);
    if (!raw) {
      return fallback;
    }

    try {
      return JSON.parse(raw) as T;
    } catch {
      return fallback;
    }
  }

  private write<T>(key: string, value: T) {
    localStorage.setItem(key, JSON.stringify(value));
  }

  private addLog(entry: Omit<LogEntry, "id" | "timestamp">) {
    const currentLogs = this.read<LogEntry[]>(STORAGE_KEYS.logs, []);
    const nextLog: LogEntry = {
      ...entry,
      id: createId("log"),
      timestamp: new Date().toISOString(),
    };

    const nextLogs = [nextLog, ...currentLogs].slice(0, MAX_LOGS);
    this.write(STORAGE_KEYS.logs, nextLogs);
  }

  private clamp(value: number, min: number, max: number): number {
    if (Number.isNaN(value)) {
      return min;
    }
    return Math.min(Math.max(value, min), max);
  }

  private parseFiniteNumber(value: unknown, fallback: number): number {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : fallback;
  }

  private isValidDiscordWebhook(url: string): boolean {
    return /^https:\/\/discord\.com\/api\/webhooks\/\d+\/[\w-]+/i.test(url.trim());
  }

  private readDiscordRuntime(): DiscordRuntimeState {
    const raw = this.read<Partial<DiscordRuntimeState>>(STORAGE_KEYS.discordRuntime, INITIAL_DISCORD_RUNTIME);
    return {
      sentWindowStart: raw.sentWindowStart?.trim() || "",
      sentInWindow: Math.max(0, Math.trunc(Number(raw.sentInWindow ?? 0))),
      lastError: raw.lastError?.trim() || "",
      lastSuccessAt: raw.lastSuccessAt?.trim() || "",
      successfulDispatches: Math.max(0, Math.trunc(Number(raw.successfulDispatches ?? 0))),
      failedDispatches: Math.max(0, Math.trunc(Number(raw.failedDispatches ?? 0))),
      saleDispatchByChannel: raw.saleDispatchByChannel ?? {},
      saleHashByChannel: raw.saleHashByChannel ?? {},
      consecutiveFailuresByChannel: raw.consecutiveFailuresByChannel ?? {},
      channelCircuitOpenUntil: raw.channelCircuitOpenUntil ?? {},
    };
  }

  private writeDiscordRuntime(runtime: DiscordRuntimeState) {
    this.write(STORAGE_KEYS.discordRuntime, runtime);
  }

  private shouldSkipByQuietHours(config: DiscordConfig): boolean {
    const start = this.clamp(Number(config.quietHoursStart), 0, 23);
    const end = this.clamp(Number(config.quietHoursEnd), 0, 23);
    if (start === end) {
      return false;
    }

    const currentHour = new Date().getHours();
    if (start < end) {
      return currentHour >= start && currentHour < end;
    }
    return currentHour >= start || currentHour < end;
  }

  private async enqueueDiscordJob(job: () => Promise<void>): Promise<void> {
    const scheduled = this.discordQueue.then(job, job);
    this.discordQueue = scheduled.then(
      () => undefined,
      () => undefined
    );
    return scheduled;
  }

  private async reserveRateLimitSlot(config: DiscordConfig): Promise<void> {
    const limit = this.clamp(Math.trunc(config.maxMessagesPerMinute), 1, 120);
    const now = new Date();
    const runtime = this.readDiscordRuntime();
    const windowStart = runtime.sentWindowStart ? new Date(runtime.sentWindowStart) : null;
    const sameMinute =
      windowStart &&
      windowStart.getFullYear() === now.getFullYear() &&
      windowStart.getMonth() === now.getMonth() &&
      windowStart.getDate() === now.getDate() &&
      windowStart.getHours() === now.getHours() &&
      windowStart.getMinutes() === now.getMinutes();

    if (!sameMinute) {
      runtime.sentWindowStart = now.toISOString();
      runtime.sentInWindow = 0;
    }

    if (runtime.sentInWindow >= limit) {
      const nextMinute = new Date(now);
      nextMinute.setSeconds(60, 50);
      const waitMs = Math.max(150, nextMinute.getTime() - now.getTime());
      this.addLog({
        level: "WARN",
        action: "DISCORD_RATE_LIMIT_WAIT",
        message: "Fila do bot aguardando proxima janela",
        meta: `Limite de ${limit} msg/min | espera ${waitMs}ms`,
      });
      await this.wait(waitMs);
      const refreshed = this.readDiscordRuntime();
      refreshed.sentWindowStart = new Date().toISOString();
      refreshed.sentInWindow = 0;
      this.writeDiscordRuntime(refreshed);
      return;
    }

    runtime.sentInWindow += 1;
    this.writeDiscordRuntime(runtime);
  }

  private markDiscordSuccess() {
    const runtime = this.readDiscordRuntime();
    runtime.lastSuccessAt = new Date().toISOString();
    runtime.successfulDispatches += 1;
    runtime.lastError = "";
    this.writeDiscordRuntime(runtime);
  }

  private markDiscordFailure(message: string, channelId?: string, config?: DiscordConfig) {
    const runtime = this.readDiscordRuntime();
    runtime.failedDispatches += 1;
    runtime.lastError = message;

    if (channelId) {
      runtime.consecutiveFailuresByChannel[channelId] =
        (runtime.consecutiveFailuresByChannel[channelId] ?? 0) + 1;

      if (config) {
        const threshold = this.clamp(Math.trunc(config.circuitBreakerFailures), 1, 10);
        if (runtime.consecutiveFailuresByChannel[channelId] >= threshold) {
          const cooldownSeconds = this.clamp(
            Math.trunc(config.circuitBreakerCooldownSeconds),
            15,
            600
          );
          const openUntil = new Date(Date.now() + cooldownSeconds * 1000).toISOString();
          runtime.channelCircuitOpenUntil[channelId] = openUntil;
          this.addLog({
            level: "WARN",
            action: "DISCORD_CIRCUIT_OPEN",
            message: `Canal entrou em protecao por falhas consecutivas`,
            meta: `${channelId} ate ${new Date(openUntil).toLocaleString("pt-BR")}`,
          });
        }
      }
    }

    this.writeDiscordRuntime(runtime);
  }

  private clearChannelFailureState(channelId: string) {
    const runtime = this.readDiscordRuntime();
    runtime.consecutiveFailuresByChannel[channelId] = 0;
    delete runtime.channelCircuitOpenUntil[channelId];
    this.writeDiscordRuntime(runtime);
  }

  private isChannelCircuitOpen(channelId: string): boolean {
    const runtime = this.readDiscordRuntime();
    const openUntil = runtime.channelCircuitOpenUntil[channelId];
    if (!openUntil) {
      return false;
    }

    if (new Date(openUntil).getTime() <= Date.now()) {
      delete runtime.channelCircuitOpenUntil[channelId];
      runtime.consecutiveFailuresByChannel[channelId] = 0;
      this.writeDiscordRuntime(runtime);
      return false;
    }

    return true;
  }

  private canDispatchSaleToChannel(channel: DiscordChannel, sale: Sale, config: DiscordConfig): boolean {
    const runtime = this.readDiscordRuntime();
    const saleKey = `${sale.id}_${sale.total}_${sale.timestamp}`;
    const lastKey = runtime.saleHashByChannel[channel.id];
    if (config.deduplicateSales && lastKey && lastKey === saleKey) {
      this.addLog({
        level: "WARN",
        action: "DISCORD_SALE_DEDUPLICATED",
        message: `Venda repetida ignorada para ${channel.name}`,
        meta: sale.id,
      });
      return false;
    }

    const lastSentAt = runtime.saleDispatchByChannel[channel.id];
    if (lastSentAt) {
      const elapsed = Date.now() - new Date(lastSentAt).getTime();
      const cooldownMs = this.clamp(Math.trunc(config.saleCooldownSeconds), 0, 600) * 1000;
      if (cooldownMs > 0 && elapsed < cooldownMs) {
        this.addLog({
          level: "WARN",
          action: "DISCORD_SALE_COOLDOWN",
          message: `Canal ${channel.name} em cooldown para venda`,
          meta: `${Math.ceil((cooldownMs - elapsed) / 1000)}s restantes`,
        });
        return false;
      }
    }

    return true;
  }

  private rememberSaleDispatch(channelId: string, sale: Sale) {
    const runtime = this.readDiscordRuntime();
    runtime.saleDispatchByChannel[channelId] = new Date().toISOString();
    runtime.saleHashByChannel[channelId] = `${sale.id}_${sale.total}_${sale.timestamp}`;
    this.writeDiscordRuntime(runtime);
  }

  private normalizeSale(rawSale: unknown, productMap: Map<string, Product>): Sale | null {
    if (!rawSale || typeof rawSale !== "object") {
      return null;
    }

    const source = rawSale as {
      id?: string;
      items?: Array<{
        productId?: string;
        productName?: string;
        quantity?: number;
        unitPrice?: number;
        total?: number;
      }>;
      total?: number;
      timestamp?: string;
      productId?: string;
      quantity?: number;
      unitPrice?: number;
      orgCommissionPercent?: number;
      memberCommissionPercent?: number;
      memberName?: string;
      orgCommissionValue?: number;
      memberCommissionValue?: number;
    };

    if (Array.isArray(source.items) && source.items.length > 0) {
      const normalizedItems: SaleItem[] = source.items
        .map((item) => {
          const productId = item.productId ?? "";
          const fallbackProduct = productMap.get(productId);
          const quantity = Number(item.quantity ?? 0);
          const unitPrice = Number(item.unitPrice ?? fallbackProduct?.price ?? 0);
          if (!productId || quantity <= 0 || unitPrice < 0) {
            return null;
          }

          return {
            productId,
            productName: item.productName ?? fallbackProduct?.name ?? "Produto removido",
            quantity,
            unitPrice,
            total: Number((item.total ?? unitPrice * quantity).toFixed(2)),
          };
        })
        .filter((item): item is SaleItem => item !== null);

      if (normalizedItems.length === 0) {
        return null;
      }

      const total = Number(
        (source.total ?? normalizedItems.reduce((sum, item) => sum + item.total, 0)).toFixed(2)
      );

      return {
        id: source.id ?? createId("sale"),
        items: normalizedItems,
        total,
        timestamp: source.timestamp ? new Date(source.timestamp).toISOString() : new Date().toISOString(),
        orgCommissionPercent: Number(source.orgCommissionPercent ?? 0),
        memberCommissionPercent: Number(source.memberCommissionPercent ?? 0),
        memberName: source.memberName?.trim() || "Nao informado",
        orgCommissionValue: Number(source.orgCommissionValue ?? 0),
        memberCommissionValue: Number(source.memberCommissionValue ?? 0),
      };
    }

    if (source.productId && source.quantity && source.unitPrice !== undefined) {
      const product = productMap.get(source.productId);
      const quantity = Number(source.quantity);
      const unitPrice = Number(source.unitPrice);
      if (quantity <= 0 || unitPrice < 0) {
        return null;
      }

      const item: SaleItem = {
        productId: source.productId,
        productName: product?.name ?? "Produto removido",
        quantity,
        unitPrice,
        total: Number((unitPrice * quantity).toFixed(2)),
      };

      return {
        id: source.id ?? createId("sale"),
        items: [item],
        total: Number((source.total ?? item.total).toFixed(2)),
        timestamp: source.timestamp ? new Date(source.timestamp).toISOString() : new Date().toISOString(),
        orgCommissionPercent: Number(source.orgCommissionPercent ?? 0),
        memberCommissionPercent: Number(source.memberCommissionPercent ?? 0),
        memberName: source.memberName?.trim() || "Nao informado",
        orgCommissionValue: Number(source.orgCommissionValue ?? 0),
        memberCommissionValue: Number(source.memberCommissionValue ?? 0),
      };
    }

    return null;
  }

  async getState(): Promise<DashboardState> {
    const products = this.read<Product[]>(STORAGE_KEYS.products, []);
    const productMap = new Map(products.map((item) => [item.id, item]));
    const rawSales = this.read<unknown[]>(STORAGE_KEYS.sales, []);
    const sales = rawSales
      .map((sale) => this.normalizeSale(sale, productMap))
      .filter((sale): sale is Sale => sale !== null)
      .sort((a, b) => +new Date(b.timestamp) - +new Date(a.timestamp));

    this.write(STORAGE_KEYS.sales, sales);

    const discordConfigRaw = this.read<unknown>(STORAGE_KEYS.discordConfig, INITIAL_DISCORD_CONFIG);
    const discordConfig = this.normalizeDiscordConfig(discordConfigRaw);
    this.write(STORAGE_KEYS.discordConfig, discordConfig);

    return {
      products,
      sales,
      logs: this.read<LogEntry[]>(STORAGE_KEYS.logs, []),
      discordConfig,
      commissionConfig: this.read<CommissionConfig>(
        STORAGE_KEYS.commissionConfig,
        INITIAL_COMMISSION_CONFIG
      ),
    };
  }

  async createProduct(name: string, price: number): Promise<void> {
    const products = this.read<Product[]>(STORAGE_KEYS.products, []);
    const product: Product = {
      id: createId("product"),
      name,
      price,
      createdAt: new Date().toISOString(),
    };

    this.write(STORAGE_KEYS.products, [product, ...products]);
    this.addLog({
      level: "INFO",
      action: "PRODUCT_CREATED",
      message: `Produto criado: ${name}`,
      meta: `Preco ${currencyFormatter.format(price)}`,
    });
  }

  private normalizeDiscordConfig(rawConfig: unknown): DiscordConfig {
    const base = { ...INITIAL_DISCORD_CONFIG };
    if (!rawConfig || typeof rawConfig !== "object") {
      return base;
    }

    const source = rawConfig as Partial<DiscordConfig> & {
      channelName?: string;
      webhookUrl?: string;
    };

    const channelsFromRaw = Array.isArray(source.channels)
      ? source.channels
          .map((channel) => {
            if (!channel || typeof channel !== "object") {
              return null;
            }

            const candidate = channel as Partial<DiscordChannel>;
            if (!candidate.webhookUrl && !candidate.name) {
              return null;
            }

            return {
              id: candidate.id || createId("discord_channel"),
              name: candidate.name?.trim() || "#canal-vendas",
              webhookUrl: candidate.webhookUrl?.trim() || "",
              enabled: candidate.enabled !== false,
              mention: candidate.mention?.trim() || "",
              useEmbeds: candidate.useEmbeds !== false,
              sendSales: candidate.sendSales !== false,
              sendCommissionAlerts: Boolean(candidate.sendCommissionAlerts),
              sendDigest: candidate.sendDigest !== false,
              allowManualCommands: candidate.allowManualCommands !== false,
              pausedUntil: candidate.pausedUntil?.trim() || "",
              minSaleValue: Math.max(0, this.parseFiniteNumber(candidate.minSaleValue, 0)),
            };
          })
          .filter((channel): channel is DiscordChannel => channel !== null)
      : [];

    const legacyChannel =
      source.webhookUrl || source.channelName
        ? {
            id: createId("discord_channel"),
            name: source.channelName?.trim() || "#controle-vendas",
            webhookUrl: source.webhookUrl?.trim() || "",
            enabled: source.enabled !== false,
            mention: "",
            useEmbeds: true,
            sendSales: true,
            sendCommissionAlerts: false,
            sendDigest: true,
            allowManualCommands: true,
            pausedUntil: "",
            minSaleValue: 0,
          }
        : null;

    const channels = channelsFromRaw.length > 0 ? channelsFromRaw : legacyChannel ? [legacyChannel] : [];

    return {
      botName: source.botName?.trim() || "EGITO",
      avatarUrl: source.avatarUrl?.trim() || "",
      enabled: Boolean(source.enabled),
      defaultMention: source.defaultMention?.trim() || "",
      signature: source.signature?.trim() || base.signature,
      retryAttempts: this.clamp(Number(source.retryAttempts ?? base.retryAttempts), 1, 5),
      retryDelayMs: this.clamp(Number(source.retryDelayMs ?? base.retryDelayMs), 250, 10_000),
      requestTimeoutMs: this.clamp(Number(source.requestTimeoutMs ?? base.requestTimeoutMs), 1000, 15000),
      maxMessagesPerMinute: this.clamp(
        Number(source.maxMessagesPerMinute ?? base.maxMessagesPerMinute),
        1,
        120
      ),
      deduplicateSales: source.deduplicateSales !== false,
      saleCooldownSeconds: this.clamp(
        Number(source.saleCooldownSeconds ?? base.saleCooldownSeconds),
        0,
        600
      ),
      circuitBreakerFailures: this.clamp(
        Number(source.circuitBreakerFailures ?? base.circuitBreakerFailures),
        1,
        10
      ),
      circuitBreakerCooldownSeconds: this.clamp(
        Number(source.circuitBreakerCooldownSeconds ?? base.circuitBreakerCooldownSeconds),
        15,
        600
      ),
      quietHoursStart: this.clamp(Number(source.quietHoursStart ?? base.quietHoursStart), 0, 23),
      quietHoursEnd: this.clamp(Number(source.quietHoursEnd ?? base.quietHoursEnd), 0, 23),
      saleTemplate: source.saleTemplate?.trim() || base.saleTemplate,
      commissionTemplate: source.commissionTemplate?.trim() || base.commissionTemplate,
      manualTemplate: source.manualTemplate?.trim() || base.manualTemplate,
      commissionAlertThreshold: Math.max(
        0,
        this.parseFiniteNumber(source.commissionAlertThreshold, base.commissionAlertThreshold)
      ),
      digestHour: this.clamp(Number(source.digestHour ?? base.digestHour), 0, 23),
      digestLastSentAt: source.digestLastSentAt?.trim() || "",
      channels,
    };
  }

  private fillTemplate(template: string, replacements: Record<string, string>): string {
    return template.replace(/\{(\w+)\}/g, (_, key: string) => replacements[key] ?? `{${key}}`);
  }

  private buildSaleTemplateData(sale: Sale): Record<string, string> {
    return {
      total: currencyFormatter.format(sale.total),
      datetime: new Date(sale.timestamp).toLocaleString("pt-BR"),
      items: sale.items.map((item) => `${item.productName} x${item.quantity}`).join(" | "),
      itemCount: String(sale.items.length),
      member: sale.memberName,
      orgCommission: currencyFormatter.format(sale.orgCommissionValue),
      memberCommission: currencyFormatter.format(sale.memberCommissionValue),
    };
  }

  private async wait(durationMs: number): Promise<void> {
    await new Promise((resolve) => window.setTimeout(resolve, durationMs));
  }

  private async sendToDiscordChannel(
    channel: DiscordChannel,
    config: DiscordConfig,
    text: string,
    action: string,
    eventLabel: string
  ): Promise<void> {
    if (!channel.enabled || !channel.webhookUrl) {
      this.addLog({
        level: "WARN",
        action: "DISCORD_CHANNEL_SKIPPED",
        message: `Canal ${channel.name} ignorado`,
        meta: "Canal desativado ou sem webhook",
      });
      return;
    }

    if (!this.isValidDiscordWebhook(channel.webhookUrl)) {
      throw new Error("Webhook do Discord invalido.");
    }

    if (this.isChannelCircuitOpen(channel.id)) {
      this.addLog({
        level: "WARN",
        action: "DISCORD_CIRCUIT_SKIPPED",
        message: `Canal ${channel.name} em protecao temporaria por falhas`,
      });
      return;
    }

    const mention = channel.mention.trim() || config.defaultMention.trim();
    const signature = config.signature.trim();
    const signedText = signature ? `${text}\n${signature}` : text;
    const attempts = Math.max(1, Math.trunc(config.retryAttempts));
    const delay = Math.max(250, Math.trunc(config.retryDelayMs));
    const timeoutMs = Math.max(1000, Math.trunc(config.requestTimeoutMs));
    let lastError = "Erro desconhecido";

    for (let index = 0; index < attempts; index += 1) {
      try {
        await this.reserveRateLimitSlot(config);
        await this.enqueueDiscordJob(async () => {
          const payload = channel.useEmbeds
            ? {
                username: config.botName || "EGITO",
                avatar_url: config.avatarUrl || undefined,
                content: mention || undefined,
                embeds: [
                  {
                    title: `${config.botName || "EGITO"} | ${eventLabel}`,
                    description: signedText,
                    color: 0xf97316,
                    footer: { text: channel.name },
                    timestamp: new Date().toISOString(),
                  },
                ],
              }
            : {
                username: config.botName || "EGITO",
                avatar_url: config.avatarUrl || undefined,
                content: `${mention ? `${mention}\n` : ""}[${channel.name}] ${signedText}`,
              };
          const controller = new AbortController();
          const timeout = window.setTimeout(() => controller.abort(), timeoutMs);
          let response: Response;
          try {
            response = await fetch(channel.webhookUrl, {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
              },
              body: JSON.stringify(payload),
              signal: controller.signal,
            });
          } finally {
            window.clearTimeout(timeout);
          }

          if (!response.ok) {
            throw new Error(`Discord retornou status ${response.status}`);
          }
        });

        this.markDiscordSuccess();
        this.clearChannelFailureState(channel.id);

        this.addLog({
          level: "INFO",
          action,
          message: `Mensagem enviada para ${channel.name}`,
          meta: `${eventLabel} | tentativa ${index + 1}`,
        });
        return;
      } catch (error) {
        lastError = error instanceof Error ? error.message : "Erro desconhecido";
        this.markDiscordFailure(lastError, channel.id, config);
        if (index < attempts - 1) {
          this.addLog({
            level: "WARN",
            action: "DISCORD_RETRYING",
            message: `Reenvio para ${channel.name}`,
            meta: `tentativa ${index + 2} de ${attempts}`,
          });
          await this.wait(delay * (index + 1));
        }
      }
    }

    throw new Error(lastError);
  }

  async createSale(
    itemsInput: Array<{ productId: string; quantity: number }>,
    saleAt: string,
    commissionConfig: CommissionConfig
  ): Promise<Sale> {
    const products = this.read<Product[]>(STORAGE_KEYS.products, []);
    const productMap = new Map(products.map((item) => [item.id, item]));
    const parsedDate = new Date(saleAt);
    if (Number.isNaN(parsedDate.getTime())) {
      throw new Error("Data da venda invalida.");
    }

    const orgPercent = this.clamp(Number(commissionConfig.orgPercent), 0, 100);
    const memberPercent = this.clamp(Number(commissionConfig.memberPercent), 0, 100);
    if (orgPercent + memberPercent > 100) {
      throw new Error("Comissao invalida: soma acima de 100%.");
    }

    const items: SaleItem[] = itemsInput.map((source) => {
      const product = productMap.get(source.productId);
      if (!product) {
        throw new Error("Produto nao encontrado.");
      }

      const quantity = Math.trunc(Number(source.quantity));
      if (Number.isNaN(quantity) || quantity <= 0) {
        throw new Error("Quantidade invalida para venda.");
      }

      return {
        productId: product.id,
        productName: product.name,
        quantity,
        unitPrice: product.price,
        total: Number((product.price * quantity).toFixed(2)),
      };
    });

    const total = Number(items.reduce((sum, item) => sum + item.total, 0).toFixed(2));
    const sales = this.read<Sale[]>(STORAGE_KEYS.sales, []);
    const orgCommissionValue = Number(((total * orgPercent) / 100).toFixed(2));
    const memberCommissionValue = Number(((total * memberPercent) / 100).toFixed(2));
    const sale: Sale = {
      id: createId("sale"),
      items,
      total,
      timestamp: parsedDate.toISOString(),
      orgCommissionPercent: orgPercent,
      memberCommissionPercent: memberPercent,
      memberName: commissionConfig.memberName.trim() || "Nao informado",
      orgCommissionValue,
      memberCommissionValue,
    };

    this.write(STORAGE_KEYS.sales, [sale, ...sales]);

    const resume = items
      .map((item) => `${item.productName} x${item.quantity}`)
      .slice(0, 4)
      .join(", ");

    this.addLog({
      level: "INFO",
      action: "SALE_CREATED",
      message: `Venda registrada com ${items.length} item(ns)`,
      meta: `${resume} | Total ${currencyFormatter.format(total)} | Org ${currencyFormatter.format(orgCommissionValue)} | ${sale.memberName} ${currencyFormatter.format(memberCommissionValue)}`,
    });

    return sale;
  }

  async saveCommissionConfig(config: CommissionConfig): Promise<void> {
    this.write(STORAGE_KEYS.commissionConfig, config);
    this.addLog({
      level: "INFO",
      action: "COMMISSION_CONFIG_UPDATED",
      message: "Configuracao de comissao atualizada",
      meta: `Org ${config.orgPercent}% | ${config.memberName} ${config.memberPercent}%`,
    });
  }

  async saveDiscordConfig(config: DiscordConfig): Promise<void> {
    const normalizedConfig = this.normalizeDiscordConfig(config);
    this.write(STORAGE_KEYS.discordConfig, normalizedConfig);
    this.addLog({
      level: "INFO",
      action: "DISCORD_CONFIG_UPDATED",
      message: "Bot EGITO configurado",
      meta: `${normalizedConfig.botName} | ${normalizedConfig.channels.length} canal(is)`,
    });
  }

  async clearLogs(): Promise<void> {
    this.write(STORAGE_KEYS.logs, []);
  }

  async runSystemAuditAndRepair(): Promise<SystemAuditReport> {
    const warnings: string[] = [];
    let fixedIssues = 0;

    const products = this.read<Product[]>(STORAGE_KEYS.products, []);
    const normalizedProducts = products.filter(
      (product) =>
        Boolean(product?.id) &&
        Boolean(product?.name?.trim()) &&
        Number.isFinite(Number(product.price)) &&
        Number(product.price) > 0
    );
    if (normalizedProducts.length !== products.length) {
      this.write(STORAGE_KEYS.products, normalizedProducts);
      fixedIssues += products.length - normalizedProducts.length;
      warnings.push("Produtos invalidos foram removidos.");
    }

    const state = await this.getState();
    const normalizedCommission: CommissionConfig = {
      memberName: state.commissionConfig.memberName?.trim() || "Membro Padrao",
      orgPercent: this.clamp(Number(state.commissionConfig.orgPercent), 0, 100),
      memberPercent: this.clamp(Number(state.commissionConfig.memberPercent), 0, 100),
    };
    if (normalizedCommission.orgPercent + normalizedCommission.memberPercent > 100) {
      normalizedCommission.memberPercent = Math.max(0, 100 - normalizedCommission.orgPercent);
      fixedIssues += 1;
      warnings.push("Comissao ajustada para nao ultrapassar 100%.");
    }
    this.write(STORAGE_KEYS.commissionConfig, normalizedCommission);

    const config = this.normalizeDiscordConfig(
      this.read<unknown>(STORAGE_KEYS.discordConfig, INITIAL_DISCORD_CONFIG)
    );
    const uniqueIds = new Set<string>();
    const repairedChannels = config.channels.map((channel) => {
      const nextId = uniqueIds.has(channel.id) ? createId("discord_channel") : channel.id;
      uniqueIds.add(nextId);
      if (nextId !== channel.id) {
        fixedIssues += 1;
        warnings.push(`ID duplicado no canal ${channel.name} foi corrigido.`);
      }
      if (channel.webhookUrl && !this.isValidDiscordWebhook(channel.webhookUrl)) {
        warnings.push(`Webhook com formato invalido detectado em ${channel.name}.`);
      }
      return { ...channel, id: nextId };
    });

    this.write(STORAGE_KEYS.discordConfig, { ...config, channels: repairedChannels });

    const logs = this.read<LogEntry[]>(STORAGE_KEYS.logs, []);
    if (logs.length > MAX_LOGS) {
      this.write(STORAGE_KEYS.logs, logs.slice(0, MAX_LOGS));
      fixedIssues += logs.length - MAX_LOGS;
      warnings.push("Logs antigos foram compactados para manter performance.");
    }

    this.addLog({
      level: "INFO",
      action: "SYSTEM_AUDIT_EXECUTED",
      message: "Verificacao completa do sistema concluida",
      meta: `Correcoes: ${fixedIssues} | Alertas: ${warnings.length}`,
    });

    return {
      totalIssues: fixedIssues + warnings.length,
      fixedIssues,
      warnings,
    };
  }

  async getDiscordRuntimeState(): Promise<DiscordRuntimeState> {
    return this.readDiscordRuntime();
  }

  async resetDiscordRuntimeState(): Promise<void> {
    this.writeDiscordRuntime(INITIAL_DISCORD_RUNTIME);
    this.addLog({
      level: "INFO",
      action: "DISCORD_RUNTIME_RESET",
      message: "Metricas de runtime do bot foram resetadas",
    });
  }

  async validateDiscordChannels(): Promise<{ valid: number; invalid: number }> {
    const config = this.normalizeDiscordConfig(
      this.read<unknown>(STORAGE_KEYS.discordConfig, INITIAL_DISCORD_CONFIG)
    );

    let valid = 0;
    let invalid = 0;
    config.channels.forEach((channel) => {
      const isValid = this.isValidDiscordWebhook(channel.webhookUrl);
      if (isValid) {
        valid += 1;
      } else {
        invalid += 1;
      }
      this.addLog({
        level: isValid ? "INFO" : "WARN",
        action: "DISCORD_WEBHOOK_VALIDATION",
        message: `${channel.name} ${isValid ? "validado" : "invalido"}`,
        meta: channel.webhookUrl.slice(0, 90),
      });
    });

    return { valid, invalid };
  }

  async sendDiscordTestNotification(testText: string): Promise<void> {
    const config = this.normalizeDiscordConfig(
      this.read<unknown>(STORAGE_KEYS.discordConfig, INITIAL_DISCORD_CONFIG)
    );

    if (!config.enabled || config.channels.length === 0) {
      this.addLog({
        level: "WARN",
        action: "DISCORD_SKIPPED",
        message: "Envio para Discord ignorado",
        meta: "Bot desativado ou sem canais configurados",
      });
      return;
    }

    const text = `[Teste EGITO] ${testText}`;

    await Promise.all(
      config.channels.map(async (channel) => {
        try {
          await this.sendToDiscordChannel(channel, config, text, "DISCORD_TEST_SENT", "Teste");
        } catch (error) {
          const message = error instanceof Error ? error.message : "Erro desconhecido";
          this.addLog({
            level: "ERROR",
            action: "DISCORD_TEST_FAILED",
            message: `Falha no canal ${channel.name}`,
            meta: message,
          });
        }
      })
    );
  }

  async sendDiscordTestToChannel(channelId: string, testText: string): Promise<void> {
    const config = this.normalizeDiscordConfig(
      this.read<unknown>(STORAGE_KEYS.discordConfig, INITIAL_DISCORD_CONFIG)
    );
    const targetChannel = config.channels.find((channel) => channel.id === channelId);
    if (!config.enabled || !targetChannel) {
      return;
    }

    await this.sendToDiscordChannel(
      targetChannel,
      config,
      `[Teste EGITO Canal] ${testText}`,
      "DISCORD_TEST_CHANNEL_SENT",
      "Teste de Canal"
    );
  }

  async sendManualDiscordMessage(text: string, targetChannelId: string): Promise<void> {
    const config = this.normalizeDiscordConfig(
      this.read<unknown>(STORAGE_KEYS.discordConfig, INITIAL_DISCORD_CONFIG)
    );
    const inputText = text.trim();
    if (!config.enabled || !inputText) {
      return;
    }

    const baseData = {
      datetime: new Date().toLocaleString("pt-BR"),
      message: inputText,
    };
    const manualMessage = this.fillTemplate(config.manualTemplate, baseData);
    const channels =
      targetChannelId === "all"
        ? config.channels.filter(
            (channel) =>
              channel.enabled &&
              channel.webhookUrl &&
              channel.allowManualCommands &&
              (!channel.pausedUntil || new Date(channel.pausedUntil).getTime() <= Date.now())
          )
        : config.channels.filter(
            (channel) =>
              channel.id === targetChannelId &&
              channel.enabled &&
              channel.webhookUrl &&
              channel.allowManualCommands &&
              (!channel.pausedUntil || new Date(channel.pausedUntil).getTime() <= Date.now())
          );

    if (channels.length === 0) {
      this.addLog({
        level: "WARN",
        action: "DISCORD_MANUAL_SKIPPED",
        message: "Mensagem manual ignorada",
        meta: "Nenhum canal valido para envio",
      });
      return;
    }

    await Promise.all(
      channels.map(async (channel) => {
        try {
          await this.sendToDiscordChannel(
            channel,
            config,
            manualMessage,
            "DISCORD_MANUAL_SENT",
            "Comando Manual"
          );
        } catch (error) {
          const message = error instanceof Error ? error.message : "Erro desconhecido";
          this.addLog({
            level: "ERROR",
            action: "DISCORD_MANUAL_FAILED",
            message: `Falha no comando manual para ${channel.name}`,
            meta: message,
          });
        }
      })
    );
  }

  async sendDailyDigest(force = false): Promise<void> {
    const config = this.normalizeDiscordConfig(
      this.read<unknown>(STORAGE_KEYS.discordConfig, INITIAL_DISCORD_CONFIG)
    );
    if (!config.enabled || config.channels.length === 0) {
      return;
    }

    const now = new Date();
    const lastDigestDate = config.digestLastSentAt ? new Date(config.digestLastSentAt) : null;
    const alreadySentToday =
      Boolean(lastDigestDate) &&
      lastDigestDate?.getDate() === now.getDate() &&
      lastDigestDate?.getMonth() === now.getMonth() &&
      lastDigestDate?.getFullYear() === now.getFullYear();

    if (!force && (alreadySentToday || now.getHours() < config.digestHour)) {
      return;
    }

    const sales = this.read<Sale[]>(STORAGE_KEYS.sales, []).filter((sale) => {
      const saleDate = new Date(sale.timestamp);
      return (
        saleDate.getDate() === now.getDate() &&
        saleDate.getMonth() === now.getMonth() &&
        saleDate.getFullYear() === now.getFullYear()
      );
    });

    const total = sales.reduce((sum, sale) => sum + sale.total, 0);
    const units = sales.reduce(
      (sum, sale) => sum + sale.items.reduce((inner, item) => inner + item.quantity, 0),
      0
    );
    const productTotals = new Map<string, number>();
    sales.forEach((sale) => {
      sale.items.forEach((item) => {
        productTotals.set(item.productName, (productTotals.get(item.productName) ?? 0) + item.total);
      });
    });
    const topProducts = [...productTotals.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .map(([name, value]) => `${name}: ${currencyFormatter.format(value)}`)
      .join(" | ");

    const digestText =
      `Resumo diario ${now.toLocaleDateString("pt-BR")}` +
      ` | Vendas: ${sales.length}` +
      ` | Unidades: ${numberFormatter.format(units)}` +
      ` | Receita: ${currencyFormatter.format(total)}` +
      `${topProducts ? ` | Top: ${topProducts}` : ""}`;

    const digestChannels = config.channels.filter(
      (channel) =>
        channel.enabled &&
        channel.webhookUrl &&
        channel.sendDigest &&
        (!channel.pausedUntil || new Date(channel.pausedUntil).getTime() <= Date.now())
    );
    if (digestChannels.length === 0) {
      return;
    }

    await Promise.all(
      digestChannels.map(async (channel) => {
        try {
          await this.sendToDiscordChannel(
            channel,
            config,
            digestText,
            "DISCORD_DIGEST_SENT",
            "Resumo Diario"
          );
        } catch (error) {
          const message = error instanceof Error ? error.message : "Erro desconhecido";
          this.addLog({
            level: "ERROR",
            action: "DISCORD_DIGEST_FAILED",
            message: `Falha ao enviar resumo para ${channel.name}`,
            meta: message,
          });
        }
      })
    );

    const nextConfig = {
      ...config,
      digestLastSentAt: now.toISOString(),
    };
    this.write(STORAGE_KEYS.discordConfig, nextConfig);
  }

  async notifySaleOnDiscord(sale: Sale): Promise<void> {
    const config = this.normalizeDiscordConfig(
      this.read<unknown>(STORAGE_KEYS.discordConfig, INITIAL_DISCORD_CONFIG)
    );

    if (!config.enabled || config.channels.length === 0) {
      return;
    }

    const saleData = this.buildSaleTemplateData(sale);
    const saleMessage = this.fillTemplate(config.saleTemplate, saleData);
    const commissionMessage = this.fillTemplate(config.commissionTemplate, saleData);
    const quietHours = this.shouldSkipByQuietHours(config);

    await Promise.all(
      config.channels.map(async (channel) => {
        if (!channel.enabled || !channel.webhookUrl) {
          return;
        }

        if (channel.pausedUntil && new Date(channel.pausedUntil).getTime() > Date.now()) {
          this.addLog({
            level: "WARN",
            action: "DISCORD_CHANNEL_PAUSED",
            message: `Canal ${channel.name} pausado temporariamente`,
          });
          return;
        }

        try {
          if (channel.sendSales && sale.total >= channel.minSaleValue && this.canDispatchSaleToChannel(channel, sale, config)) {
            await this.sendToDiscordChannel(channel, config, saleMessage, "DISCORD_SALE_SENT", "Venda");
            this.rememberSaleDispatch(channel.id, sale);
          }

          if (
            !quietHours &&
            channel.sendCommissionAlerts &&
            sale.memberCommissionValue >= Math.max(config.commissionAlertThreshold, 0)
          ) {
            await this.sendToDiscordChannel(
              channel,
              config,
              commissionMessage,
              "DISCORD_COMMISSION_ALERT_SENT",
              "Comissao"
            );
          }
        } catch (error) {
          const message = error instanceof Error ? error.message : "Erro desconhecido";
          this.addLog({
            level: "ERROR",
            action: "DISCORD_AUTOMATION_FAILED",
            message: `Falha na automacao para ${channel.name}`,
            meta: message,
          });
        }
      })
    );
  }
}

const backend = new LocalBackend();

function toInputDateTime(value: Date) {
  const localISOTime = new Date(value.getTime() - value.getTimezoneOffset() * 60000).toISOString();
  return localISOTime.slice(0, 16);
}

function sameDay(a: Date, b: Date) {
  return (
    a.getFullYear() === b.getFullYear() &&
    a.getMonth() === b.getMonth() &&
    a.getDate() === b.getDate()
  );
}

function buildInitialSaleItem(defaultProductId = ""): SaleDraftItem {
  return {
    id: createId("draft"),
    productId: defaultProductId,
    quantity: "1",
  };
}

export default function App() {
  const [products, setProducts] = useState<Product[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [discordConfig, setDiscordConfig] = useState<DiscordConfig>(INITIAL_DISCORD_CONFIG);
  const [commissionConfig, setCommissionConfig] =
    useState<CommissionConfig>(INITIAL_COMMISSION_CONFIG);
  const [toast, setToast] = useState<ToastState | null>(null);

  const [productName, setProductName] = useState("");
  const [productPrice, setProductPrice] = useState("");

  const [saleItems, setSaleItems] = useState<SaleDraftItem[]>([buildInitialSaleItem()]);
  const [saleDateTime, setSaleDateTime] = useState(toInputDateTime(new Date()));
  const [discordChannelDraft, setDiscordChannelDraft] = useState<DiscordChannelDraft>(
    INITIAL_DISCORD_CHANNEL_DRAFT
  );

  const [sendingDiscord, setSendingDiscord] = useState(false);
  const [manualDiscordMessage, setManualDiscordMessage] = useState("");
  const [manualDiscordTarget, setManualDiscordTarget] = useState("all");
  const [activeTab, setActiveTab] = useState<"principal" | "produto" | "discord">("principal");
  const [currentTime, setCurrentTime] = useState(() => new Date());
  const [logLevelFilter, setLogLevelFilter] = useState<"ALL" | LogLevel>("ALL");
  const [logQuery, setLogQuery] = useState("");
  const [discordRuntime, setDiscordRuntime] = useState<DiscordRuntimeState>(INITIAL_DISCORD_RUNTIME);

  const notify = (text: string, tone: ToastState["tone"] = "info") => {
    setToast({ id: createId("toast"), text, tone });
  };

  const loadData = async () => {
    const state = await backend.getState();
    const runtime = await backend.getDiscordRuntimeState();
    setProducts(state.products);
    setSales(state.sales);
    setLogs(state.logs);
    setDiscordConfig(state.discordConfig);
    setCommissionConfig(state.commissionConfig);
    setDiscordRuntime(runtime);
  };

  useEffect(() => {
    void loadData();
  }, []);

  useEffect(() => {
    const timer = window.setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    const digestTimer = window.setInterval(() => {
      void backend.sendDailyDigest(false);
    }, 60_000);

    return () => window.clearInterval(digestTimer);
  }, []);

  useEffect(() => {
    if (!toast) {
      return;
    }

    const toastTimer = window.setTimeout(() => {
      setToast(null);
    }, 3600);

    return () => window.clearTimeout(toastTimer);
  }, [toast]);

  useEffect(() => {
    if (products.length === 0) {
      return;
    }

    setSaleItems((prev) =>
      prev.map((item) => {
        if (item.productId) {
          return item;
        }
        return { ...item, productId: products[0].id };
      })
    );
  }, [products]);

  const productMap = useMemo(() => new Map(products.map((item) => [item.id, item])), [products]);

  const today = new Date();
  const todaySales = useMemo(() => {
    return sales.filter((sale) => sameDay(new Date(sale.timestamp), today));
  }, [sales, today]);

  const todayRevenue = todaySales.reduce((sum, sale) => sum + sale.total, 0);
  const todayUnits = todaySales.reduce(
    (sum, sale) => sum + sale.items.reduce((innerSum, item) => innerSum + item.quantity, 0),
    0
  );

  const totalRevenue = sales.reduce((sum, sale) => sum + sale.total, 0);
  const todayOrgCommission = todaySales.reduce((sum, sale) => sum + sale.orgCommissionValue, 0);
  const todayMemberCommission = todaySales.reduce((sum, sale) => sum + sale.memberCommissionValue, 0);
  const todayAvgTicket = todaySales.length > 0 ? todayRevenue / todaySales.length : 0;
  const commissionTotal = sales.reduce(
    (sum, sale) => sum + sale.orgCommissionValue + sale.memberCommissionValue,
    0
  );

  const salesByHour = useMemo(() => {
    const buckets = Array.from({ length: 24 }, (_, hour) => ({
      hour: `${hour.toString().padStart(2, "0")}h`,
      vendas: 0,
    }));

    todaySales.forEach((sale) => {
      const hour = new Date(sale.timestamp).getHours();
      buckets[hour].vendas += sale.total;
    });

    return buckets;
  }, [todaySales]);

  const salesByDay = useMemo(() => {
    const result: { dia: string; vendas: number }[] = [];

    for (let index = 6; index >= 0; index -= 1) {
      const date = new Date();
      date.setDate(today.getDate() - index);
      const key = date.toISOString().slice(0, 10);

      const total = sales
        .filter((sale) => sale.timestamp.startsWith(key))
        .reduce((sum, sale) => sum + sale.total, 0);

      result.push({
        dia: date.toLocaleDateString("pt-BR", { weekday: "short" }),
        vendas: Number(total.toFixed(2)),
      });
    }

    return result;
  }, [sales, today]);

  const topProducts = useMemo(() => {
    const acc = new Map<string, number>();
    sales.forEach((sale) => {
      sale.items.forEach((item) => {
        acc.set(item.productName, (acc.get(item.productName) ?? 0) + item.total);
      });
    });

    return [...acc.entries()]
      .map(([name, total]) => ({ name, total }))
      .sort((a, b) => b.total - a.total)
      .slice(0, 6);
  }, [sales]);

  const draftTotal = useMemo(() => {
    return saleItems.reduce((sum, item) => {
      const quantity = Number(item.quantity);
      const unitPrice = productMap.get(item.productId)?.price ?? 0;
      if (!item.productId || Number.isNaN(quantity) || quantity <= 0) {
        return sum;
      }
      return sum + quantity * unitPrice;
    }, 0);
  }, [saleItems, productMap]);

  const recentSales = sales.slice(0, 6);
  const activeDiscordChannels = discordConfig.channels.filter((channel) => channel.enabled).length;
  const openCircuits = Object.values(discordRuntime.channelCircuitOpenUntil).filter(
    (value) => new Date(value).getTime() > Date.now()
  ).length;
  const logsFiltered = logs.filter((log) => {
    const byLevel = logLevelFilter === "ALL" || log.level === logLevelFilter;
    const query = logQuery.trim().toLowerCase();
    const byQuery =
      query.length === 0 ||
      log.message.toLowerCase().includes(query) ||
      log.action.toLowerCase().includes(query) ||
      (log.meta?.toLowerCase().includes(query) ?? false);
    return byLevel && byQuery;
  });

  const handleProductSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const price = Number(productPrice.replace(",", "."));

    if (!productName.trim() || Number.isNaN(price) || price <= 0) {
      notify("Informe nome e preco valido para cadastrar o produto.", "error");
      return;
    }

    await backend.createProduct(productName.trim(), price);
    setProductName("");
    setProductPrice("");
    notify("Produto criado com sucesso.", "success");
    await loadData();
  };

  const updateSaleItem = (id: string, patch: Partial<SaleDraftItem>) => {
    setSaleItems((prev) => prev.map((item) => (item.id === id ? { ...item, ...patch } : item)));
  };

  const addSaleItem = () => {
    setSaleItems((prev) => [...prev, buildInitialSaleItem(products[0]?.id ?? "")]);
  };

  const removeSaleItem = (id: string) => {
    setSaleItems((prev) => {
      if (prev.length <= 1) {
        return prev;
      }
      return prev.filter((item) => item.id !== id);
    });
  };

  const handleSaleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (products.length === 0) {
      notify("Cadastre ao menos um produto antes de registrar venda.", "error");
      return;
    }

    const grouped = new Map<string, number>();

    for (const item of saleItems) {
      const quantity = Number(item.quantity);
      if (!item.productId || Number.isNaN(quantity) || quantity <= 0) {
        notify("Preencha todos os itens da venda com produto e quantidade valida.", "error");
        return;
      }
      grouped.set(item.productId, (grouped.get(item.productId) ?? 0) + quantity);
    }

    if (!commissionConfig.memberName.trim()) {
      notify("Informe o nome do membro para aplicar a comissao na venda.", "error");
      return;
    }

    const payload = [...grouped.entries()].map(([productId, quantity]) => ({ productId, quantity }));
    const createdSale = await backend.createSale(payload, saleDateTime, commissionConfig);
    await backend.notifySaleOnDiscord(createdSale);

    setSaleItems([buildInitialSaleItem(products[0]?.id ?? "")]);
    setSaleDateTime(toInputDateTime(new Date()));
    notify("Venda com multiplos produtos registrada com sucesso.", "success");
    await loadData();
  };

  const handleCommissionSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const orgPercent = Number(commissionConfig.orgPercent);
    const memberPercent = Number(commissionConfig.memberPercent);

    if (!commissionConfig.memberName.trim()) {
      notify("Informe o nome do membro para salvar a comissao.", "error");
      return;
    }

    if (Number.isNaN(orgPercent) || Number.isNaN(memberPercent) || orgPercent < 0 || memberPercent < 0) {
      notify("As porcentagens de comissao devem ser numeros validos.", "error");
      return;
    }

    if (orgPercent + memberPercent > 100) {
      notify("A soma das comissoes de org e membro nao pode ultrapassar 100%.", "error");
      return;
    }

    const normalizedConfig: CommissionConfig = {
      memberName: commissionConfig.memberName.trim(),
      orgPercent: Number(orgPercent.toFixed(2)),
      memberPercent: Number(memberPercent.toFixed(2)),
    };

    await backend.saveCommissionConfig(normalizedConfig);
    notify("Configuracao de comissao salva.", "success");
    await loadData();
  };

  const handleDiscordConfigSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (discordConfig.enabled && discordConfig.channels.every((channel) => !channel.webhookUrl.trim())) {
      notify("Adicione ao menos um webhook valido para ativar o bot EGITO.", "error");
      return;
    }

    if (
      Number.isNaN(discordConfig.retryAttempts) ||
      Number.isNaN(discordConfig.retryDelayMs) ||
      Number.isNaN(discordConfig.requestTimeoutMs) ||
      Number.isNaN(discordConfig.maxMessagesPerMinute) ||
      discordConfig.retryAttempts < 1 ||
      discordConfig.retryAttempts > 5 ||
      discordConfig.retryDelayMs < 250 ||
      discordConfig.requestTimeoutMs < 1000 ||
      discordConfig.maxMessagesPerMinute < 1
    ) {
      notify("Revise tentativas, delays e limites de envio do bot.", "error");
      return;
    }

    if (
      Number.isNaN(discordConfig.circuitBreakerFailures) ||
      Number.isNaN(discordConfig.circuitBreakerCooldownSeconds) ||
      discordConfig.circuitBreakerFailures < 1 ||
      discordConfig.circuitBreakerFailures > 10 ||
      discordConfig.circuitBreakerCooldownSeconds < 15 ||
      discordConfig.circuitBreakerCooldownSeconds > 600
    ) {
      notify("Protecao de falhas do bot esta fora dos limites permitidos.", "error");
      return;
    }

    if (
      discordConfig.saleCooldownSeconds < 0 ||
      discordConfig.saleCooldownSeconds > 600 ||
      discordConfig.quietHoursStart < 0 ||
      discordConfig.quietHoursStart > 23 ||
      discordConfig.quietHoursEnd < 0 ||
      discordConfig.quietHoursEnd > 23
    ) {
      notify("Cooldown e horarios silenciosos devem estar entre limites validos.", "error");
      return;
    }

    await backend.saveDiscordConfig(discordConfig);
    notify("Configuracao avancada do bot EGITO salva no localStorage.", "success");
    await loadData();
  };

  const addDiscordChannel = () => {
    if (!discordChannelDraft.name.trim() || !discordChannelDraft.webhookUrl.trim()) {
      notify("Informe nome do canal e webhook para adicionar.", "error");
      return;
    }

    const minSaleValue = Number(discordChannelDraft.minSaleValue.replace(",", "."));
    if (Number.isNaN(minSaleValue) || minSaleValue < 0) {
      notify("O valor minimo por venda do canal deve ser valido.", "error");
      return;
    }

    if (!/^https:\/\/discord\.com\/api\/webhooks\/\d+\/[\w-]+/i.test(discordChannelDraft.webhookUrl.trim())) {
      notify("Webhook invalido. Use a URL completa de webhook do Discord.", "error");
      return;
    }

    const nextChannel: DiscordChannel = {
      id: createId("discord_channel"),
      name: discordChannelDraft.name.trim(),
      webhookUrl: discordChannelDraft.webhookUrl.trim(),
      enabled: true,
      mention: discordChannelDraft.mention.trim(),
      useEmbeds: discordChannelDraft.useEmbeds,
      sendSales: discordChannelDraft.sendSales,
      sendCommissionAlerts: discordChannelDraft.sendCommissionAlerts,
      sendDigest: discordChannelDraft.sendDigest,
      allowManualCommands: discordChannelDraft.allowManualCommands,
      pausedUntil: "",
      minSaleValue: Number(minSaleValue.toFixed(2)),
    };

    setDiscordConfig((prev) => ({ ...prev, channels: [nextChannel, ...prev.channels] }));
    setDiscordChannelDraft(INITIAL_DISCORD_CHANNEL_DRAFT);
    notify("Canal de Discord adicionado ao bot EGITO.", "success");
  };

  const removeDiscordChannel = (id: string) => {
    setDiscordConfig((prev) => ({
      ...prev,
      channels: prev.channels.filter((channel) => channel.id !== id),
    }));
  };

  const patchDiscordChannel = (id: string, patch: Partial<DiscordChannel>) => {
    setDiscordConfig((prev) => ({
      ...prev,
      channels: prev.channels.map((channel) =>
        channel.id === id
          ? {
              ...channel,
              ...patch,
            }
          : channel
      ),
    }));
  };

  const handleDiscordTest = async () => {
    setSendingDiscord(true);
    setToast(null);
    try {
      await backend.sendDiscordTestNotification(
        `Teste do painel EGITO em ${new Date().toLocaleString("pt-BR")}`
      );
      notify("Teste enviado para os canais ativos do bot EGITO.", "success");
    } catch {
      notify("Falha ao enviar para Discord. Veja os logs para detalhes.", "error");
    } finally {
      setSendingDiscord(false);
      await loadData();
    }
  };

  const handleManualDiscordSend = async () => {
    if (!manualDiscordMessage.trim()) {
      notify("Escreva uma mensagem para usar o comando manual do bot.", "error");
      return;
    }

    setSendingDiscord(true);
    setToast(null);
    try {
      await backend.sendManualDiscordMessage(manualDiscordMessage, manualDiscordTarget);
      notify("Comando manual enviado para o Discord.", "success");
      setManualDiscordMessage("");
    } catch {
      notify("Falha ao enviar comando manual. Confira os logs.", "error");
    } finally {
      setSendingDiscord(false);
      await loadData();
    }
  };

  const handleDigestNow = async () => {
    setSendingDiscord(true);
    setToast(null);
    try {
      await backend.sendDailyDigest(true);
      notify("Resumo diario enviado para os canais configurados.", "success");
    } catch {
      notify("Falha ao enviar resumo diario. Confira os logs.", "error");
    } finally {
      setSendingDiscord(false);
      await loadData();
    }
  };

  const handleValidateWebhooks = async () => {
    setSendingDiscord(true);
    try {
      const result = await backend.validateDiscordChannels();
      notify(`Validacao concluida: ${result.valid} valido(s), ${result.invalid} invalido(s).`, "info");
    } catch {
      notify("Falha durante validacao de webhooks.", "error");
    } finally {
      setSendingDiscord(false);
      await loadData();
    }
  };

  const handleClearLogs = async () => {
    await backend.clearLogs();
    notify("Logs limpos.", "success");
    await loadData();
  };

  const handleResetDiscordRuntime = async () => {
    await backend.resetDiscordRuntimeState();
    notify("Metricas de runtime do bot foram resetadas.", "success");
    await loadData();
  };

  const handleSystemAudit = async () => {
    setSendingDiscord(true);
    try {
      const report = await backend.runSystemAuditAndRepair();
      const prefix = `Verificacao concluida: ${report.fixedIssues} correcao(oes)`;
      const details = report.warnings.length > 0 ? ` | alertas: ${report.warnings.length}` : "";
      notify(`${prefix}${details}.`, "success");
    } catch {
      notify("Falha ao executar verificacao completa do sistema.", "error");
    } finally {
      setSendingDiscord(false);
      await loadData();
    }
  };

  const handleChannelTest = async (channelId: string) => {
    setSendingDiscord(true);
    try {
      await backend.sendDiscordTestToChannel(
        channelId,
        `Teste dedicado em ${new Date().toLocaleString("pt-BR")}`
      );
      notify("Teste enviado para o canal selecionado.", "success");
    } catch {
      notify("Falha no teste do canal. Verifique webhook e logs.", "error");
    } finally {
      setSendingDiscord(false);
      await loadData();
    }
  };

  return (
    <div className="relative min-h-screen overflow-hidden bg-black text-zinc-100">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -top-24 left-1/2 h-[28rem] w-[28rem] -translate-x-1/2 rounded-full bg-orange-500/20 blur-3xl" />
        <div className="absolute bottom-0 right-0 h-96 w-96 rounded-full bg-amber-500/10 blur-3xl" />
        <div className="absolute left-0 top-1/3 h-72 w-72 rounded-full bg-orange-700/15 blur-3xl" />
      </div>

      <motion.header
        initial={{ opacity: 0, y: -18 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.45 }}
        className="relative border-b border-orange-500/30 bg-black/70 backdrop-blur"
      >
        <div className="mx-auto flex w-full max-w-7xl flex-col gap-3 px-6 py-8 md:flex-row md:items-end md:justify-between">
          <div>
            <h1 className="text-4xl font-semibold tracking-[0.2em] text-orange-400">EGITO</h1>
          </div>
          <div className="text-sm text-zinc-500">{currentTime.toLocaleString("pt-BR")}</div>
        </div>
      </motion.header>

      <main className="relative mx-auto grid w-full max-w-7xl gap-8 px-6 py-8 lg:grid-cols-[1.35fr_1fr]">
        <section className="space-y-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45, delay: 0.1 }}
            className="space-y-4"
          >
            <div className="grid gap-4 sm:grid-cols-3">
              <div className="border border-orange-500/40 bg-zinc-950/70 p-4 backdrop-blur">
                <p className="text-xs uppercase tracking-[0.22em] text-zinc-400">Faturamento Hoje</p>
                <motion.p
                  key={todayRevenue}
                  initial={{ opacity: 0, scale: 0.96 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="mt-2 text-2xl font-semibold text-orange-300"
                >
                  {currencyFormatter.format(todayRevenue)}
                </motion.p>
              </div>
              <div className="border border-orange-500/40 bg-zinc-950/70 p-4 backdrop-blur">
                <p className="text-xs uppercase tracking-[0.22em] text-zinc-400">Unidades Hoje</p>
                <motion.p
                  key={todayUnits}
                  initial={{ opacity: 0, scale: 0.96 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="mt-2 text-2xl font-semibold text-white"
                >
                  {numberFormatter.format(todayUnits)}
                </motion.p>
              </div>
              <div className="border border-orange-500/40 bg-zinc-950/70 p-4 backdrop-blur">
                <p className="text-xs uppercase tracking-[0.22em] text-zinc-400">Faturamento Total</p>
                <motion.p
                  key={totalRevenue}
                  initial={{ opacity: 0, scale: 0.96 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="mt-2 text-2xl font-semibold text-white"
                >
                  {currencyFormatter.format(totalRevenue)}
                </motion.p>
              </div>
            </div>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <div className="border border-orange-500/35 bg-zinc-950/60 p-4">
                <p className="text-xs uppercase tracking-[0.2em] text-zinc-400">Comissao Org Hoje</p>
                <p className="mt-2 text-xl font-semibold text-orange-200">
                  {currencyFormatter.format(todayOrgCommission)}
                </p>
              </div>
              <div className="border border-orange-500/35 bg-zinc-950/60 p-4">
                <p className="text-xs uppercase tracking-[0.2em] text-zinc-400">
                  Comissao {commissionConfig.memberName || "Membro"} Hoje
                </p>
                <p className="mt-2 text-xl font-semibold text-orange-200">
                  {currencyFormatter.format(todayMemberCommission)}
                </p>
              </div>
              <div className="border border-orange-500/35 bg-zinc-950/60 p-4">
                <p className="text-xs uppercase tracking-[0.2em] text-zinc-400">Ticket Medio Hoje</p>
                <p className="mt-2 text-xl font-semibold text-orange-100">
                  {currencyFormatter.format(todayAvgTicket)}
                </p>
              </div>
              <div className="border border-orange-500/35 bg-zinc-950/60 p-4">
                <p className="text-xs uppercase tracking-[0.2em] text-zinc-400">Comissao Total</p>
                <p className="mt-2 text-xl font-semibold text-orange-100">
                  {currencyFormatter.format(commissionTotal)}
                </p>
              </div>
            </div>
          </motion.div>

          <motion.section
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45, delay: 0.16 }}
            className="border border-orange-500/40 bg-zinc-950/65 p-4 backdrop-blur"
          >
            <div className="mb-4">
              <h2 className="text-lg font-medium text-white">Vendas por Hora</h2>
              <p className="text-sm text-zinc-400">Volume de hoje distribuido por horario.</p>
            </div>
            <div className="h-64 w-full">
              <ResponsiveContainer>
                <LineChart data={salesByHour}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
                  <XAxis dataKey="hour" stroke="#a1a1aa" />
                  <YAxis stroke="#a1a1aa" />
                  <Tooltip
                    formatter={(value) => currencyFormatter.format(Number(value ?? 0))}
                    contentStyle={{ backgroundColor: "#09090b", border: "1px solid #f97316" }}
                  />
                  <Line type="monotone" dataKey="vendas" stroke="#fb923c" strokeWidth={2.5} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </motion.section>

          <motion.section
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45, delay: 0.22 }}
            className="grid gap-6 lg:grid-cols-2"
          >
            <div className="border border-orange-500/40 bg-zinc-950/65 p-4 backdrop-blur">
              <h2 className="text-lg font-medium text-white">Rendimento por Dia</h2>
              <p className="mb-3 text-sm text-zinc-400">Ultimos 7 dias de faturamento.</p>
              <div className="h-56 w-full">
                <ResponsiveContainer>
                  <BarChart data={salesByDay}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
                    <XAxis dataKey="dia" stroke="#a1a1aa" />
                    <YAxis stroke="#a1a1aa" />
                    <Tooltip
                      formatter={(value) => currencyFormatter.format(Number(value ?? 0))}
                      contentStyle={{ backgroundColor: "#09090b", border: "1px solid #f97316" }}
                    />
                    <Bar dataKey="vendas" radius={[2, 2, 0, 0]}>
                      {salesByDay.map((entry) => (
                        <Cell key={entry.dia} fill={entry.vendas > 0 ? "#f97316" : "#3f3f46"} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="border border-orange-500/40 bg-zinc-950/65 p-4 backdrop-blur">
              <h2 className="text-lg font-medium text-white">Produtos com Melhor Resultado</h2>
              <p className="mb-3 text-sm text-zinc-400">Comparativo por faturamento acumulado.</p>
              <div className="space-y-3">
                {topProducts.length === 0 && (
                  <p className="text-sm text-zinc-500">Ainda nao existem vendas para analisar.</p>
                )}
                {topProducts.map((item, index) => (
                  <div key={item.name} className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span className="text-zinc-200">{item.name}</span>
                      <span className="text-orange-300">{currencyFormatter.format(item.total)}</span>
                    </div>
                    <div className="h-1.5 bg-zinc-800">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${Math.min((item.total / (topProducts[0]?.total || 1)) * 100, 100)}%` }}
                        transition={{ duration: 0.5, delay: 0.1 + index * 0.06 }}
                        className="h-full bg-orange-400"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </motion.section>
        </section>

        <aside className="space-y-5 border border-orange-500/40 bg-zinc-950/70 p-4 backdrop-blur">
          <div className="grid grid-cols-3 gap-2 text-xs uppercase tracking-[0.18em]">
            <button
              onClick={() => setActiveTab("principal")}
              className={`border px-2 py-2 transition ${
                activeTab === "principal"
                  ? "border-orange-300 bg-orange-500/20 text-orange-200"
                  : "border-zinc-700 text-zinc-400 hover:border-zinc-500"
              }`}
            >
              Principal
            </button>
            <button
              onClick={() => setActiveTab("produto")}
              className={`border px-2 py-2 transition ${
                activeTab === "produto"
                  ? "border-orange-300 bg-orange-500/20 text-orange-200"
                  : "border-zinc-700 text-zinc-400 hover:border-zinc-500"
              }`}
            >
              Produto
            </button>
            <button
              onClick={() => setActiveTab("discord")}
              className={`border px-2 py-2 transition ${
                activeTab === "discord"
                  ? "border-orange-300 bg-orange-500/20 text-orange-200"
                  : "border-zinc-700 text-zinc-400 hover:border-zinc-500"
              }`}
            >
              Discord
            </button>
          </div>

          {activeTab === "principal" && (
            <motion.div
              key="tab-principal"
              initial={{ opacity: 0, x: 12 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.25 }}
              className="space-y-5"
            >
              <section className="border border-zinc-700 bg-black/50 p-4">
                <h2 className="text-lg font-medium text-white">Comissao de Venda</h2>
                <p className="mb-4 text-sm text-zinc-400">
                  Defina a comissao em percentual para org e membro nas proximas vendas.
                </p>
                <form className="space-y-3" onSubmit={handleCommissionSubmit}>
                  <input
                    value={commissionConfig.memberName}
                    onChange={(event) =>
                      setCommissionConfig((prev) => ({
                        ...prev,
                        memberName: event.target.value,
                      }))
                    }
                    placeholder="Nome do membro"
                    className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm outline-none focus:border-orange-300"
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="number"
                      min="0"
                      max="100"
                      step="0.1"
                      value={commissionConfig.orgPercent}
                      onChange={(event) =>
                        setCommissionConfig((prev) => ({
                          ...prev,
                          orgPercent: Number(event.target.value),
                        }))
                      }
                      placeholder="% Org"
                      className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm outline-none focus:border-orange-300"
                    />
                    <input
                      type="number"
                      min="0"
                      max="100"
                      step="0.1"
                      value={commissionConfig.memberPercent}
                      onChange={(event) =>
                        setCommissionConfig((prev) => ({
                          ...prev,
                          memberPercent: Number(event.target.value),
                        }))
                      }
                      placeholder="% Membro"
                      className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm outline-none focus:border-orange-300"
                    />
                  </div>
                  <p className="text-xs text-zinc-500">
                    Comissao total configurada: {(commissionConfig.orgPercent + commissionConfig.memberPercent).toFixed(1)}%
                  </p>
                  <button
                    type="submit"
                    className="w-full bg-orange-500 px-3 py-2 text-sm font-semibold text-black transition hover:bg-orange-400"
                  >
                    Salvar comissao
                  </button>
                </form>
              </section>

              <section className="border border-zinc-700 bg-black/50 p-4">
                <h2 className="text-lg font-medium text-white">Registrar Venda</h2>
                <p className="mb-4 text-sm text-zinc-400">
                  Adicione um ou mais produtos na mesma venda.
                </p>
                <form className="space-y-3" onSubmit={handleSaleSubmit}>
                  {saleItems.map((item, index) => (
                    <div key={item.id} className="space-y-2 border border-zinc-800 p-3">
                      <p className="text-xs uppercase tracking-[0.15em] text-zinc-500">Item {index + 1}</p>
                      <select
                        value={item.productId}
                        onChange={(event) => updateSaleItem(item.id, { productId: event.target.value })}
                        className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm outline-none focus:border-orange-300"
                      >
                        <option value="">Selecione o produto</option>
                        {products.map((product) => (
                          <option key={product.id} value={product.id}>
                            {product.name} - {currencyFormatter.format(product.price)}
                          </option>
                        ))}
                      </select>
                      <div className="grid grid-cols-[1fr_auto] gap-2">
                        <input
                          type="number"
                          min="1"
                          value={item.quantity}
                          onChange={(event) => updateSaleItem(item.id, { quantity: event.target.value })}
                          className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm outline-none focus:border-orange-300"
                        />
                        <button
                          type="button"
                          onClick={() => removeSaleItem(item.id)}
                          disabled={saleItems.length <= 1}
                          className="border border-zinc-700 px-3 py-2 text-xs text-zinc-300 transition hover:border-orange-400 hover:text-orange-200 disabled:cursor-not-allowed disabled:opacity-50"
                        >
                          Remover
                        </button>
                      </div>
                    </div>
                  ))}

                  <button
                    type="button"
                    onClick={addSaleItem}
                    className="w-full border border-orange-400/60 px-3 py-2 text-sm text-orange-200 transition hover:bg-orange-500/10"
                  >
                    + Adicionar produto
                  </button>

                  <input
                    type="datetime-local"
                    value={saleDateTime}
                    onChange={(event) => setSaleDateTime(event.target.value)}
                    className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm outline-none focus:border-orange-300"
                  />

                  <div className="border border-zinc-800 bg-zinc-950/60 px-3 py-2 text-sm text-zinc-300">
                    Total desta venda: <span className="font-semibold text-orange-300">{currencyFormatter.format(draftTotal)}</span>
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-orange-500 px-3 py-2 text-sm font-semibold text-black transition hover:bg-orange-400"
                  >
                    Salvar venda
                  </button>
                </form>
              </section>

              <section className="border border-zinc-700 bg-black/50 p-4">
                <h2 className="text-lg font-medium text-white">Ultimas Vendas</h2>
                <div className="mt-3 space-y-2 text-sm">
                  {recentSales.length === 0 && <p className="text-zinc-500">Sem vendas registradas.</p>}
                  {recentSales.map((sale) => (
                    <div key={sale.id} className="border-b border-zinc-800 pb-2">
                      <div className="flex items-center justify-between gap-3">
                        <p className="text-zinc-200">{new Date(sale.timestamp).toLocaleString("pt-BR")}</p>
                        <p className="text-orange-300">{currencyFormatter.format(sale.total)}</p>
                      </div>
                      <p className="mt-1 text-xs text-zinc-500">
                        {sale.items.map((item) => `${item.productName} x${item.quantity}`).join(" | ")}
                      </p>
                      <p className="mt-1 text-xs text-zinc-500">
                        Org {sale.orgCommissionPercent}% ({currencyFormatter.format(sale.orgCommissionValue)}) | {sale.memberName} {sale.memberCommissionPercent}% ({currencyFormatter.format(sale.memberCommissionValue)})
                      </p>
                    </div>
                  ))}
                </div>
              </section>
            </motion.div>
          )}

          {activeTab === "produto" && (
            <motion.div
              key="tab-produto"
              initial={{ opacity: 0, x: 12 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.25 }}
              className="space-y-5"
            >
              <section className="border border-zinc-700 bg-black/50 p-4">
                <h2 className="text-lg font-medium text-white">Novo Produto</h2>
                <p className="mb-4 text-sm text-zinc-400">Cadastre nome e valor unitario.</p>
                <form className="space-y-3" onSubmit={handleProductSubmit}>
                  <input
                    value={productName}
                    onChange={(event) => setProductName(event.target.value)}
                    placeholder="Nome do produto"
                    className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm outline-none focus:border-orange-300"
                  />
                  <input
                    value={productPrice}
                    onChange={(event) => setProductPrice(event.target.value)}
                    placeholder="Preco ex: 149.90"
                    className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm outline-none focus:border-orange-300"
                  />
                  <button
                    type="submit"
                    className="w-full bg-orange-500 px-3 py-2 text-sm font-semibold text-black transition hover:bg-orange-400"
                  >
                    Criar produto
                  </button>
                </form>
              </section>

              <section className="border border-zinc-700 bg-black/50 p-4">
                <h2 className="text-lg font-medium text-white">Produtos Cadastrados</h2>
                <div className="mt-3 max-h-64 space-y-2 overflow-auto pr-1 text-sm">
                  {products.length === 0 && <p className="text-zinc-500">Nenhum produto criado.</p>}
                  {products.map((product) => (
                    <div key={product.id} className="flex items-center justify-between border-b border-zinc-800 pb-2">
                      <p className="text-zinc-200">{product.name}</p>
                      <p className="text-orange-300">{currencyFormatter.format(product.price)}</p>
                    </div>
                  ))}
                </div>
              </section>
            </motion.div>
          )}

          {activeTab === "discord" && (
            <motion.div
              key="tab-discord"
              initial={{ opacity: 0, x: 12 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.25 }}
              className="space-y-5"
            >
              <section className="border border-zinc-700 bg-black/50 p-4">
                <h2 className="text-lg font-medium text-white">Bot Discord EGITO</h2>
                <p className="mb-4 text-sm text-zinc-400">
                  Sistema proprio de automacao com multiplos canais e regras por tipo de aviso.
                </p>
                <div className="mb-4 border border-zinc-800 bg-zinc-950/70 p-3 text-xs text-zinc-300">
                  Canais ativos: <span className="text-orange-300">{activeDiscordChannels}</span> de {discordConfig.channels.length}
                  <br />
                  Ultimo resumo: {discordConfig.digestLastSentAt ? new Date(discordConfig.digestLastSentAt).toLocaleString("pt-BR") : "nao enviado"}
                  <br />
                  Entregas: <span className="text-emerald-300">{discordRuntime.successfulDispatches}</span> | Falhas: <span className="text-rose-300">{discordRuntime.failedDispatches}</span>
                  <br />
                  Canais em protecao: <span className="text-amber-300">{openCircuits}</span>
                  <br />
                  Ultimo sucesso: {discordRuntime.lastSuccessAt ? new Date(discordRuntime.lastSuccessAt).toLocaleString("pt-BR") : "nenhum"}
                  {discordRuntime.lastError && (
                    <>
                      <br />
                      Ultimo erro: <span className="text-rose-300">{discordRuntime.lastError}</span>
                    </>
                  )}
                </div>
                <form className="space-y-3" onSubmit={handleDiscordConfigSubmit}>
                  <label className="flex items-center gap-2 text-sm text-zinc-300">
                    <input
                      type="checkbox"
                      checked={discordConfig.enabled}
                      onChange={(event) =>
                        setDiscordConfig((prev) => ({
                          ...prev,
                          enabled: event.target.checked,
                        }))
                      }
                    />
                    Ativar bot EGITO
                  </label>
                  <input
                    value={discordConfig.botName}
                    onChange={(event) =>
                      setDiscordConfig((prev) => ({
                        ...prev,
                        botName: event.target.value,
                      }))
                    }
                    placeholder="Nome do bot"
                    className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm outline-none focus:border-orange-300"
                  />
                  <input
                    value={discordConfig.avatarUrl}
                    onChange={(event) =>
                      setDiscordConfig((prev) => ({
                        ...prev,
                        avatarUrl: event.target.value,
                      }))
                    }
                    placeholder="Avatar URL (opcional)"
                    className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm outline-none focus:border-orange-300"
                  />
                  <input
                    value={discordConfig.defaultMention}
                    onChange={(event) =>
                      setDiscordConfig((prev) => ({
                        ...prev,
                        defaultMention: event.target.value,
                      }))
                    }
                    placeholder="Mencao global opcional (ex: @everyone ou <@&roleId>)"
                    className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm outline-none focus:border-orange-300"
                  />
                  <input
                    value={discordConfig.signature}
                    onChange={(event) =>
                      setDiscordConfig((prev) => ({
                        ...prev,
                        signature: event.target.value,
                      }))
                    }
                    placeholder="Assinatura final das mensagens"
                    className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm outline-none focus:border-orange-300"
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="number"
                      min="1"
                      max="5"
                      value={discordConfig.retryAttempts}
                      onChange={(event) =>
                        setDiscordConfig((prev) => ({
                          ...prev,
                          retryAttempts: Number(event.target.value),
                        }))
                      }
                      placeholder="Tentativas"
                      className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm outline-none focus:border-orange-300"
                    />
                    <input
                      type="number"
                      min="250"
                      max="10000"
                      value={discordConfig.retryDelayMs}
                      onChange={(event) =>
                        setDiscordConfig((prev) => ({
                          ...prev,
                          retryDelayMs: Number(event.target.value),
                        }))
                      }
                      placeholder="Delay retry (ms)"
                      className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm outline-none focus:border-orange-300"
                    />
                    <input
                      type="number"
                      min="1000"
                      max="15000"
                      value={discordConfig.requestTimeoutMs}
                      onChange={(event) =>
                        setDiscordConfig((prev) => ({
                          ...prev,
                          requestTimeoutMs: Number(event.target.value),
                        }))
                      }
                      placeholder="Timeout request (ms)"
                      className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm outline-none focus:border-orange-300"
                    />
                    <input
                      type="number"
                      min="1"
                      max="120"
                      value={discordConfig.maxMessagesPerMinute}
                      onChange={(event) =>
                        setDiscordConfig((prev) => ({
                          ...prev,
                          maxMessagesPerMinute: Number(event.target.value),
                        }))
                      }
                      placeholder="Limite msg/min"
                      className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm outline-none focus:border-orange-300"
                    />
                    <input
                      type="number"
                      min="0"
                      max="600"
                      value={discordConfig.saleCooldownSeconds}
                      onChange={(event) =>
                        setDiscordConfig((prev) => ({
                          ...prev,
                          saleCooldownSeconds: Number(event.target.value),
                        }))
                      }
                      placeholder="Cooldown venda (s)"
                      className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm outline-none focus:border-orange-300"
                    />
                    <input
                      type="number"
                      min="1"
                      max="10"
                      value={discordConfig.circuitBreakerFailures}
                      onChange={(event) =>
                        setDiscordConfig((prev) => ({
                          ...prev,
                          circuitBreakerFailures: Number(event.target.value),
                        }))
                      }
                      placeholder="Falhas para protecao"
                      className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm outline-none focus:border-orange-300"
                    />
                    <input
                      type="number"
                      min="15"
                      max="600"
                      value={discordConfig.circuitBreakerCooldownSeconds}
                      onChange={(event) =>
                        setDiscordConfig((prev) => ({
                          ...prev,
                          circuitBreakerCooldownSeconds: Number(event.target.value),
                        }))
                      }
                      placeholder="Duracao protecao (s)"
                      className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm outline-none focus:border-orange-300"
                    />
                    <input
                      type="number"
                      min="0"
                      max="23"
                      value={discordConfig.digestHour}
                      onChange={(event) =>
                        setDiscordConfig((prev) => ({
                          ...prev,
                          digestHour: Number(event.target.value),
                        }))
                      }
                      placeholder="Hora resumo"
                      className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm outline-none focus:border-orange-300"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="number"
                      min="0"
                      max="23"
                      value={discordConfig.quietHoursStart}
                      onChange={(event) =>
                        setDiscordConfig((prev) => ({
                          ...prev,
                          quietHoursStart: Number(event.target.value),
                        }))
                      }
                      placeholder="Inicio silencio"
                      className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm outline-none focus:border-orange-300"
                    />
                    <input
                      type="number"
                      min="0"
                      max="23"
                      value={discordConfig.quietHoursEnd}
                      onChange={(event) =>
                        setDiscordConfig((prev) => ({
                          ...prev,
                          quietHoursEnd: Number(event.target.value),
                        }))
                      }
                      placeholder="Fim silencio"
                      className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm outline-none focus:border-orange-300"
                    />
                  </div>
                  <label className="flex items-center gap-2 border border-zinc-800 p-2 text-xs text-zinc-300">
                    <input
                      type="checkbox"
                      checked={discordConfig.deduplicateSales}
                      onChange={(event) =>
                        setDiscordConfig((prev) => ({
                          ...prev,
                          deduplicateSales: event.target.checked,
                        }))
                      }
                    />
                    Evitar notificacoes de venda duplicadas por canal
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="1"
                    value={discordConfig.commissionAlertThreshold}
                    onChange={(event) =>
                      setDiscordConfig((prev) => ({
                        ...prev,
                        commissionAlertThreshold: Number(event.target.value),
                      }))
                    }
                    placeholder="Limite de alerta de comissao"
                    className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm outline-none focus:border-orange-300"
                  />
                  <textarea
                    value={discordConfig.saleTemplate}
                    onChange={(event) =>
                      setDiscordConfig((prev) => ({
                        ...prev,
                        saleTemplate: event.target.value,
                      }))
                    }
                    rows={2}
                    className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm outline-none focus:border-orange-300"
                  />
                  <textarea
                    value={discordConfig.commissionTemplate}
                    onChange={(event) =>
                      setDiscordConfig((prev) => ({
                        ...prev,
                        commissionTemplate: event.target.value,
                      }))
                    }
                    rows={2}
                    className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm outline-none focus:border-orange-300"
                  />
                  <textarea
                    value={discordConfig.manualTemplate}
                    onChange={(event) =>
                      setDiscordConfig((prev) => ({
                        ...prev,
                        manualTemplate: event.target.value,
                      }))
                    }
                    rows={2}
                    placeholder="Template manual: use {message} e {datetime}"
                    className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm outline-none focus:border-orange-300"
                  />
                  <p className="text-xs text-zinc-500">
                    Tags disponiveis: {"{total}"} {"{items}"} {"{member}"} {"{orgCommission}"} {"{memberCommission}"} {"{datetime}"} {"{message}"}
                  </p>
                  <button
                    type="submit"
                    className="w-full bg-orange-500 px-3 py-2 text-sm font-semibold text-black transition hover:bg-orange-400"
                  >
                    Salvar bot EGITO
                  </button>
                </form>

                <div className="mt-5 space-y-3 border-t border-zinc-800 pt-4">
                  <p className="text-sm text-zinc-300">Adicionar canal</p>
                  <input
                    value={discordChannelDraft.name}
                    onChange={(event) =>
                      setDiscordChannelDraft((prev) => ({
                        ...prev,
                        name: event.target.value,
                      }))
                    }
                    placeholder="Canal ex: #vendas"
                    className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm outline-none focus:border-orange-300"
                  />
                  <input
                    value={discordChannelDraft.webhookUrl}
                    onChange={(event) =>
                      setDiscordChannelDraft((prev) => ({
                        ...prev,
                        webhookUrl: event.target.value,
                      }))
                    }
                    placeholder="Webhook URL do canal"
                    className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm outline-none focus:border-orange-300"
                  />
                  <input
                    value={discordChannelDraft.mention}
                    onChange={(event) =>
                      setDiscordChannelDraft((prev) => ({
                        ...prev,
                        mention: event.target.value,
                      }))
                    }
                    placeholder="Mencao do canal (opcional)"
                    className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm outline-none focus:border-orange-300"
                  />
                  <input
                    value={discordChannelDraft.minSaleValue}
                    onChange={(event) =>
                      setDiscordChannelDraft((prev) => ({
                        ...prev,
                        minSaleValue: event.target.value,
                      }))
                    }
                    placeholder="Minimo de venda para avisar"
                    className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm outline-none focus:border-orange-300"
                  />
                  <div className="grid grid-cols-2 gap-2 text-xs text-zinc-300">
                    <label className="flex items-center gap-2 border border-zinc-800 p-2">
                      <input
                        type="checkbox"
                        checked={discordChannelDraft.useEmbeds}
                        onChange={(event) =>
                          setDiscordChannelDraft((prev) => ({
                            ...prev,
                            useEmbeds: event.target.checked,
                          }))
                        }
                      />
                      Usar embed
                    </label>
                    <label className="flex items-center gap-2 border border-zinc-800 p-2">
                      <input
                        type="checkbox"
                        checked={discordChannelDraft.sendSales}
                        onChange={(event) =>
                          setDiscordChannelDraft((prev) => ({
                            ...prev,
                            sendSales: event.target.checked,
                          }))
                        }
                      />
                      Aviso de venda
                    </label>
                    <label className="flex items-center gap-2 border border-zinc-800 p-2">
                      <input
                        type="checkbox"
                        checked={discordChannelDraft.sendCommissionAlerts}
                        onChange={(event) =>
                          setDiscordChannelDraft((prev) => ({
                            ...prev,
                            sendCommissionAlerts: event.target.checked,
                          }))
                        }
                      />
                      Alerta de comissao
                    </label>
                    <label className="col-span-2 flex items-center gap-2 border border-zinc-800 p-2">
                      <input
                        type="checkbox"
                        checked={discordChannelDraft.sendDigest}
                        onChange={(event) =>
                          setDiscordChannelDraft((prev) => ({
                            ...prev,
                            sendDigest: event.target.checked,
                          }))
                        }
                      />
                      Receber resumo diario
                    </label>
                  </div>
                  <button
                    type="button"
                    onClick={addDiscordChannel}
                    className="w-full border border-orange-400 px-3 py-2 text-sm text-orange-200 transition hover:bg-orange-400/10"
                  >
                    Adicionar canal ao bot
                  </button>
                </div>

                <div className="mt-4 max-h-56 space-y-2 overflow-auto pr-1">
                  {discordConfig.channels.length === 0 && (
                    <p className="text-sm text-zinc-500">Nenhum canal configurado ainda.</p>
                  )}
                  {discordConfig.channels.map((channel) => (
                    <div key={channel.id} className="space-y-2 border border-zinc-800 bg-zinc-950/60 p-3 text-xs">
                      <div className="flex items-center justify-between gap-2">
                        <p className="text-zinc-200">{channel.name}</p>
                        <button
                          type="button"
                          onClick={() => removeDiscordChannel(channel.id)}
                          className="text-rose-300 transition hover:text-rose-200"
                        >
                          Remover
                        </button>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <input
                          value={channel.name}
                          onChange={(event) =>
                            patchDiscordChannel(channel.id, {
                              name: event.target.value,
                            })
                          }
                          placeholder="Nome do canal"
                          className="w-full border border-zinc-800 bg-black px-2 py-1 text-xs text-zinc-200 outline-none focus:border-orange-300"
                        />
                        <input
                          value={channel.webhookUrl}
                          onChange={(event) =>
                            patchDiscordChannel(channel.id, {
                              webhookUrl: event.target.value,
                            })
                          }
                          placeholder="Webhook do canal"
                          className="w-full border border-zinc-800 bg-black px-2 py-1 text-xs text-zinc-200 outline-none focus:border-orange-300"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-zinc-300 md:grid-cols-6">
                        <label className="flex items-center gap-2 border border-zinc-800 p-2">
                          <input
                            type="checkbox"
                            checked={channel.enabled}
                            onChange={(event) =>
                              patchDiscordChannel(channel.id, { enabled: event.target.checked })
                            }
                          />
                          Ativo
                        </label>
                        <label className="flex items-center gap-2 border border-zinc-800 p-2">
                          <input
                            type="checkbox"
                            checked={channel.useEmbeds}
                            onChange={(event) =>
                              patchDiscordChannel(channel.id, { useEmbeds: event.target.checked })
                            }
                          />
                          Embed
                        </label>
                        <label className="flex items-center gap-2 border border-zinc-800 p-2">
                          <input
                            type="checkbox"
                            checked={channel.sendSales}
                            onChange={(event) =>
                              patchDiscordChannel(channel.id, { sendSales: event.target.checked })
                            }
                          />
                          Venda
                        </label>
                        <label className="flex items-center gap-2 border border-zinc-800 p-2">
                          <input
                            type="checkbox"
                            checked={channel.sendCommissionAlerts}
                            onChange={(event) =>
                              patchDiscordChannel(channel.id, {
                                sendCommissionAlerts: event.target.checked,
                              })
                            }
                          />
                          Comissao
                        </label>
                        <label className="flex items-center gap-2 border border-zinc-800 p-2">
                          <input
                            type="checkbox"
                            checked={channel.sendDigest}
                            onChange={(event) =>
                              patchDiscordChannel(channel.id, {
                                sendDigest: event.target.checked,
                              })
                            }
                          />
                          Resumo
                        </label>
                        <label className="flex items-center gap-2 border border-zinc-800 p-2">
                          <input
                            type="checkbox"
                            checked={channel.allowManualCommands}
                            onChange={(event) =>
                              patchDiscordChannel(channel.id, {
                                allowManualCommands: event.target.checked,
                              })
                            }
                          />
                          Manual
                        </label>
                      </div>
                      <input
                        value={channel.mention}
                        onChange={(event) =>
                          patchDiscordChannel(channel.id, {
                            mention: event.target.value,
                          })
                        }
                        placeholder="Mencao especifica do canal"
                        className="w-full border border-zinc-800 bg-black px-2 py-1 text-xs text-zinc-200 outline-none focus:border-orange-300"
                      />
                      <div className="grid grid-cols-2 gap-2">
                        <input
                          type="number"
                          min="0"
                          value={channel.minSaleValue}
                          onChange={(event) =>
                            patchDiscordChannel(channel.id, {
                              minSaleValue: Math.max(0, Number(event.target.value)),
                            })
                          }
                          placeholder="Minimo da venda"
                          className="w-full border border-zinc-800 bg-black px-2 py-1 text-xs text-zinc-200 outline-none focus:border-orange-300"
                        />
                        <input
                          type="datetime-local"
                          value={channel.pausedUntil ? toInputDateTime(new Date(channel.pausedUntil)) : ""}
                          onChange={(event) =>
                            patchDiscordChannel(channel.id, {
                              pausedUntil: event.target.value
                                ? new Date(event.target.value).toISOString()
                                : "",
                            })
                          }
                          className="w-full border border-zinc-800 bg-black px-2 py-1 text-xs text-zinc-200 outline-none focus:border-orange-300"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          disabled={sendingDiscord}
                          onClick={() => handleChannelTest(channel.id)}
                          className="border border-zinc-700 px-2 py-1 text-xs text-zinc-200 transition hover:border-orange-300 disabled:opacity-50"
                        >
                          Testar canal
                        </button>
                        <button
                          type="button"
                          onClick={() => patchDiscordChannel(channel.id, { pausedUntil: "" })}
                          className="border border-zinc-700 px-2 py-1 text-xs text-zinc-200 transition hover:border-orange-300"
                        >
                          Remover pausa
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                <button
                  onClick={handleDiscordTest}
                  disabled={sendingDiscord}
                  className="mt-3 w-full border border-orange-300 px-3 py-2 text-sm text-orange-200 transition hover:bg-orange-300/10 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {sendingDiscord ? "Enviando teste..." : "Testar bot EGITO"}
                </button>
                <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-4">
                  <button
                    type="button"
                    onClick={handleValidateWebhooks}
                    disabled={sendingDiscord}
                    className="border border-zinc-700 px-2 py-2 text-xs text-zinc-200 transition hover:border-orange-300 disabled:opacity-50"
                  >
                    Validar webhooks
                  </button>
                  <button
                    type="button"
                    onClick={handleResetDiscordRuntime}
                    className="border border-zinc-700 px-2 py-2 text-xs text-zinc-200 transition hover:border-orange-300"
                  >
                    Resetar runtime
                  </button>
                  <button
                    type="button"
                    onClick={handleClearLogs}
                    className="border border-zinc-700 px-2 py-2 text-xs text-zinc-200 transition hover:border-orange-300"
                  >
                    Limpar logs
                  </button>
                  <button
                    type="button"
                    onClick={handleSystemAudit}
                    disabled={sendingDiscord}
                    className="border border-zinc-700 px-2 py-2 text-xs text-zinc-200 transition hover:border-orange-300 disabled:opacity-50"
                  >
                    Verificar sistema
                  </button>
                </div>

                <div className="mt-4 space-y-3 border-t border-zinc-800 pt-4">
                  <h3 className="text-sm font-medium text-zinc-100">Central de Comandos</h3>
                  <textarea
                    value={manualDiscordMessage}
                    onChange={(event) => setManualDiscordMessage(event.target.value)}
                    rows={2}
                    placeholder="Mensagem manual do bot"
                    className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm outline-none focus:border-orange-300"
                  />
                  <select
                    value={manualDiscordTarget}
                    onChange={(event) => setManualDiscordTarget(event.target.value)}
                    className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm outline-none focus:border-orange-300"
                  >
                    <option value="all">Todos os canais ativos</option>
                    {discordConfig.channels.map((channel) => (
                      <option key={channel.id} value={channel.id}>
                        {channel.name}
                      </option>
                    ))}
                  </select>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={handleManualDiscordSend}
                      disabled={sendingDiscord}
                      className="border border-orange-400 px-3 py-2 text-sm text-orange-200 transition hover:bg-orange-400/10 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      Enviar comando
                    </button>
                    <button
                      type="button"
                      onClick={handleDigestNow}
                      disabled={sendingDiscord}
                      className="border border-zinc-600 px-3 py-2 text-sm text-zinc-200 transition hover:border-orange-300 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      Resumo agora
                    </button>
                  </div>
                </div>
              </section>

              <section className="border border-zinc-700 bg-black/50 p-4">
                <h2 className="text-lg font-medium text-white">Logs do Sistema</h2>
                <div className="my-3 grid grid-cols-[1fr_auto] gap-2">
                  <input
                    value={logQuery}
                    onChange={(event) => setLogQuery(event.target.value)}
                    placeholder="Buscar por acao, mensagem ou meta"
                    className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-xs outline-none focus:border-orange-300"
                  />
                  <select
                    value={logLevelFilter}
                    onChange={(event) => setLogLevelFilter(event.target.value as "ALL" | LogLevel)}
                    className="border border-zinc-700 bg-zinc-950 px-3 py-2 text-xs outline-none focus:border-orange-300"
                  >
                    <option value="ALL">Todos</option>
                    <option value="INFO">INFO</option>
                    <option value="WARN">WARN</option>
                    <option value="ERROR">ERROR</option>
                  </select>
                </div>
                <div className="max-h-72 space-y-2 overflow-auto pr-1">
                  {logsFiltered.length === 0 && <p className="text-sm text-zinc-500">Nenhum log registrado.</p>}
                  {logsFiltered.slice(0, 30).map((log) => (
                    <div key={log.id} className="border border-zinc-800 bg-zinc-950/70 p-2 text-xs">
                      <div className="flex justify-between gap-3">
                        <span
                          className={
                            log.level === "ERROR"
                              ? "text-rose-300"
                              : log.level === "WARN"
                                ? "text-amber-300"
                                : "text-orange-300"
                          }
                        >
                          {log.level}
                        </span>
                        <span className="text-zinc-500">{new Date(log.timestamp).toLocaleString("pt-BR")}</span>
                      </div>
                      <p className="mt-1 text-zinc-200">{log.message}</p>
                      <p className="text-zinc-400">{log.action}</p>
                      {log.meta && <p className="text-zinc-500">{log.meta}</p>}
                    </div>
                  ))}
                </div>
              </section>
            </motion.div>
          )}
        </aside>
      </main>

      <AnimatePresence>
        {toast && (
          <motion.div
            key={toast.id}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 12 }}
            className={`fixed bottom-4 left-1/2 flex w-[min(90vw,42rem)] -translate-x-1/2 items-start justify-between gap-3 border px-4 py-3 text-sm backdrop-blur ${
              toast.tone === "error"
                ? "border-rose-500/50 bg-zinc-950/95 text-rose-100"
                : toast.tone === "success"
                  ? "border-emerald-500/40 bg-zinc-950/95 text-emerald-100"
                  : "border-zinc-700 bg-zinc-900/95 text-zinc-200"
            }`}
          >
            <span>{toast.text}</span>
            <button
              type="button"
              onClick={() => setToast(null)}
              className="text-zinc-500 transition hover:text-zinc-200"
            >
              Fechar
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}